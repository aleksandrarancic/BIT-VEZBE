# Install plugins

* Live Preview
* HTML Boilerplate


How TO - Position Text Over an Image
https://www.w3schools.com/howto/tryit.asp?filename=tryhow_css_image_text

